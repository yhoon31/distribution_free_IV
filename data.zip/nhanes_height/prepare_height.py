
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent / 'nhanes'
sys.path.insert(0, str(NATIVE))
from prepare_nhanes import read_fixed_width

SPECIFICATION = dict(
    field='HAM5S', label='NHANES III reported height', units='inches',
    observed=19129, minimum=41., maximum=92.,
    qualification='Reported height without shoes, standardized by CDC to inches.')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n',
                         encoding='utf-8')


def binary_partition():
    """Reproduce the recorded design-only partition without changing Z."""
    meta = json.loads((NATIVE / 'prepared_natural_metadata.json').read_text())
    selected = sorted(meta['native_selected_interviewers'])
    design = pd.read_csv(NATIVE / 'native_design_holdout.csv')
    counts = design.adult_interviewer.value_counts()
    total = sum(int(counts[j]) for j in selected)
    candidates = []
    for n in range(1, len(selected)):
        for subset in itertools.combinations(selected, n):
            if selected[0] in subset:
                candidates.append((abs(total - 2 * sum(int(counts[j]) for j in subset)), subset))
    _, left = min(candidates)
    right = tuple(j for j in selected if j not in left)
    return dict(levels=['design_balanced_group_0', 'design_balanced_group_1'],
        native_codes_by_arm=[list(left), list(right)],
        design_counts_by_arm=[sum(int(counts[j]) for j in left), sum(int(counts[j]) for j in right)],
        native_design_counts={str(j): int(counts[j]) for j in selected},
        rule='Minimize absolute design-count imbalance over all partitions of the fixed five interviewers; smallest interviewer label belongs to arm 0; lexicographic tie break.',
        selection_uses_outcome=False, selection_uses_response=False,
        coarsening='deterministic independent-design frequency partition',
        coarsened_instrument=True)


def prepare(output_dir=HERE):
    """Write the five current height data/provenance files to output_dir."""
    spec = SPECIFICATION
    adult, mapping = read_fixed_width('adult', ['SEQN', spec['field']])
    assert len(adult) == 20050
    partition = binary_partition()
    assert partition['native_codes_by_arm'] == [[7005, 7016, 7024], [7020, 7067]]
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    raw = adult[spec['field']]
    valid = raw.notna() & ~raw.isin([888, 999])
    assert int(valid.sum()) == spec['observed']
    assert raw[valid].min() == spec['minimum'] and raw[valid].max() == spec['maximum']
    values = pd.Series(raw.where(valid).to_numpy(), index=adult.SEQN)
    summaries = []
    for stem in ['prepared', 'prepared_natural']:
        # Keep the same five-ID cohort in both public loader modes.
        frame = pd.read_csv(NATIVE / 'prepared_natural.csv')
        frame[spec['field']] = frame.SEQN.map(pd.Series(raw.to_numpy(), index=adult.SEQN))
        frame['outcome'] = frame.SEQN.map(values)
        frame['observed'] = frame.outcome.notna().astype(int)
        frame['measurement_status'] = np.where(frame.observed, 'observed_self_report', 'unknown_self_report')
        frame.to_csv(target / (stem + '.csv'), index=False)
        meta = json.loads((NATIVE / 'prepared_natural_metadata.json').read_text())
        meta.update(dataset=spec['label'], outcome=spec['field'], outcome_units=spec['units'],
            outcome_qualification=spec['qualification'],
            observed='Valid original adult-file item; codes 888/999 and blanks remain missing.',
            rows=len(frame), observed_rows=int(frame.observed.sum()), missing_rows=int((1-frame.observed).sum()),
            natural_target='Original interviewer cohort with genuinely unknown self-reported outcome retained.',
            benchmark_target='Originally observed self-reported outcome in the fixed interviewer cohort; artificial masking only.',
            natural_supported=True, outcomes_imputed=False, outcome_transformation='none',
            iv_validity='Exploratory interviewer candidate. Geographic assignment and direct effects on reported answers may violate conditional outcome independence.',
            binary_instrument_partition=partition,
            design_reuse='Exact prior outcome-blind five-interviewer selection; no re-selection using the self-report outcome or its availability.')
        write_json(target / (stem + '_metadata.json'), meta)
        summaries.append(dict(dataset='nhanes_height', cohort=stem, rows=len(frame),
            observed=int(frame.observed.sum()), missing=int((1-frame.observed).sum()),
            response_rate=float(frame.observed.mean())))
    write_json(target / 'source_mapping.json', dict(source='CDC NHANES III adult.dat',
        source_sha256=digest(NATIVE / 'adult.dat'), layout_sha256=digest(NATIVE / 'adult.sas'),
        field=mapping[spec['field']], missing_codes=[888, 999], blanks_missing=True,
        source_observed_count=spec['observed'], source_valid_range=[spec['minimum'], spec['maximum']],
        codebook_pages=[245, 246, 418], existing_native_cohort_sha256=digest(NATIVE / 'prepared_natural.csv')))
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=HERE)
    args = parser.parse_args()
    print(json.dumps(prepare(args.output_dir), indent=2), flush=True)


if __name__ == '__main__':
    main()
