# NHANES III public-use hemoglobin data

The files here were downloaded directly from CDC/NCHS for the replacement
NHANES III experiment requested in `Data/GPT2.txt`. No account, application,
third-party mirror, inferred individual record, or imputed outcome was used.
The immutable source-file byte counts, URLs, retrieval time, and SHA-256
checksums are in [`manifest.json`](manifest.json).

## Primary sources and reproducible preparation

- [CDC NHANES III data-download page](https://wwwn.cdc.gov/nchs/nhanes/nhanes3/datafiles.aspx),
  core release 1A, Interview & Exam Components (July 1997).
- [Household Adult ASCII file](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/adult.dat),
  [official SAS layout](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/adult.sas), and
  [Adult codebook](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/ADULT-acc.pdf).
- [Laboratory ASCII file](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/lab.dat),
  [official SAS layout](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/lab.sas), and
  [Laboratory codebook](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/lab-acc.pdf).

Run `python experiments/data/nhanes/prepare_nhanes.py` from the project root.
The script downloads missing sources, verifies cached source hashes, parses
the original SAS `INPUT` column ranges, and writes all derived CSVs and JSON
files. The `FORMAT` statements are output formatting, not implied-decimal
input specifications: the ASCII hemoglobin values already contain explicit
decimal points. No additional decimal scaling is applied. As an independent
unit check, the script verifies `HGPSI == 10 * HGP` for every observed result.
[`codebook_mapping.json`](codebook_mapping.json) contains the exact source
filename, label, and one-based inclusive column range for every extracted
variable. The text versions of the two codebooks are convenience extractions;
the original PDFs are retained.

## Cohort and linkage

`adult_merged.csv` retains all **20,050 interviewed adults aged 17 or older**.
The adult file is left-joined one-to-one to laboratory records by `SEQN`.
An inner join would lose the 1,888 adults without a laboratory record.
There are 17,170 observed adult hemoglobin values, 970 lab sentinel values,
22 blank lab values, and 1,888 adults without a lab record. All missing
hemoglobin values remain missing.

`prepared.csv` restricts only on adult-interviewer identity being available:
542 records coded `HAINTVR=8888` are excluded, leaving **19,508 adults in
12,516 families, with 87 distinct adult interviewers**. Of these adults,
16,725 have observed hemoglobin and 2,783 have unknown hemoglobin. The
observation rate is 85.734%. There is no outcome trimming, clinical-range
restriction, complete-covariate restriction, or examination-attendance
restriction. `cohort_flow.csv` and `sample_summary.json` record these counts.

`DMPFSEQ`, source columns 6--10, is the released **family sequence number**.
The Adult codebook's demographic notes (PDF page 392) explicitly identify
matching five-digit values as members of the same family. Both `family_id`
and the existing runner's technical `household_id` alias use `DMPFSEQ`.
The correct interpretation is family grouping: multiple distinct families
can share one dwelling. Survey pseudo-PSUs and strata are retained separately
and must not be mistaken for unrestricted geographic identifiers.

## Variables and missing values

| Role / alias | Source | Treatment |
|---|---|---|
| Participant `row_id` | `SEQN` | Unique merge key; never a predictor. |
| Family split group | `DMPFSEQ` | Group identifier; never a predictor. |
| `outcome` | Laboratory `HGP`, columns 1320--1324 | Hemoglobin in g/dL; literal `88888` and blank become missing. Valid observed range 4.95--19.6 matches the codebook. |
| `observed` | Valid `HGP` following left join | Includes all forms of outcome nonmeasurement. |
| `instrument`, `adult_interviewer` | `HAINTVR`, columns 1435--1438 | Categorical identity; `8888` is unavailable, never a category. |
| `family_interviewer` | `HFINTVR`, columns 1250--1253 | Alternative candidate identity; `8888` is unavailable. There are 86 valid family interviewers in the full adult sample. |
| `age` | `HSAGEIR` | Years; 90 is top-coded 90+. |
| `sex` | `HSSEX` | 1 male, 2 female, as recorded by the survey. |
| `race_ethnicity` | `DMARETHN` | Four published analytic categories; encoded categorically. |
| `education` | `HFA8R` | 0--17 valid completed school years. Sentinel 88 (blank but applicable) and 99 (unknown) receive a fixed 0 placeholder **plus** `education_missing=1` and a distinct `education_status` category. No estimated/global imputation is used. |
| `interview_language` | `HALANG` | 1 English, 2 Spanish, 3 other; 8 becomes explicit `blank_applicable`. |
| `region` | `DMPCREGN` | Census region, four categories. |
| `urban` | `DMPMETRO` | Published two-category urbanization recode, not a direct urban/rural split. Category 1 denotes central/fringe counties of metro areas with at least 1 million population; category 2 is all other areas. |
| `phase` | `SDPPHASE` | 1: 1988--1991, 2: 1991--1994. |
| `pseudo_stratum`, `pseudo_psu`, `survey_cluster`, `cluster_id` | `SDPSTRA6`, `SDPPSU6` | Survey design codes. Composite `survey_cluster` and its `cluster_id` alias are the pair, e.g. `44:1`; retained for diagnostics and sensitivity. |
| `interview_weight` | `WTPFQX6` | Retained for transparency; main repeated-split experiments are unweighted. |
| Measurement diagnostics | `DMPSTAT`, `PHPHEMO`, `PHPCHM2` | Preserved raw, not used as covariates or exclusions. |

The regression feature schema is explicit in `prepared_metadata.json`:
age, education, its missing indicator, and categorical sex, race/ethnicity,
education status, adult interview language, census region, broad urbanization,
and survey phase. Public pseudo-strata/PSUs are retained for design diagnostics
and sensitivity analyses; they are not default covariates or precise geography.
Additional raw variables and
aliases are retained for audits; their retention does not mean they are
included in the regression. In particular, outcome-proximal laboratory
exclusion flags and examination status are **not** predictors.

## Scope and interpretation

The natural candidate instrument is **adult household interviewer identity**,
not laboratory technician identity. Its validity is a hypothesis, not an
established NHANES design fact. Geographic and demographic assignment can
confound it. Interviewer relevance and overlap need empirical checks after
adjustment, and prediction sets for naturally unmeasured hemoglobin cannot
have their true empirical coverage observed.

The laboratory instructions include medical venipuncture exclusions. There
are four adults coded as having hemophilia and 18 coded as recently receiving
chemotherapy in the left-joined adult file. These participants are retained.
Consequently `observed=0` is composite measurement missingness, not a label
for refusal. Unknown medical-exclusion flags are not imputed to be negative.
The analysis begins among household-interview participants and does not
correct nonresponse to the initial household interview.

The controlled masking benchmark uses only adults with observed real
hemoglobin and creates a randomized instrument and missingness mechanism.
It is a methods experiment on that empirical population, not a claim that
the natural NHANES interviewer instrument is valid. Family-disjoint sampling
limits within-family leakage. Unweighted sample coverage does not estimate
survey-weighted coverage for the US population, and family separation does
not eliminate broader dependence from the complex survey design.
