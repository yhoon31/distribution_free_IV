"""Reproducible interviewer relevance/overlap audit; no test of IV validity.

Run after prepare_nhanes.py. A separate 20% family design sample freezes the
five interviewer labels using counts alone. Its families never enter the
native-IV experiment. All relevance comparisons use held-out families or PSUs.
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score, brier_score_loss
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE = Path(__file__).resolve().parent
SEED = 20262515
NUMERIC = ['age', 'age_squared', 'education', 'poverty_income_ratio']
CATEGORICAL = ['sex', 'race_ethnicity', 'interview_language', 'region',
               'urban', 'phase', 'education_missing', 'poverty_missing']


def frame(raw):
    aliases = {'HSAGEIR': 'age', 'HSSEX': 'sex', 'DMARETHN': 'race_ethnicity',
               'HFA8R': 'education', 'DMPPIR': 'poverty_income_ratio',
               'HALANG': 'interview_language', 'DMPCREGN': 'region',
               'DMPMETRO': 'urban', 'SDPPHASE': 'phase',
               'DMPFSEQ': 'family', 'HAINTVR': 'adult_interviewer',
               'HFINTVR': 'family_interviewer'}
    d = raw[list(aliases)].rename(columns=aliases).copy()
    d['outcome'] = raw.HGP.where(raw.HGP.between(4.95, 19.6))
    d['observed'] = d.outcome.notna().astype(int)
    d['row_id'] = raw.SEQN.astype(int)
    d['survey_cluster'] = raw.SDPSTRA6.astype(int).astype(str) + ':' + raw.SDPPSU6.astype(int).astype(str)
    d.loc[~d.education.between(0, 17), 'education'] = np.nan
    d.loc[~d.poverty_income_ratio.between(0, 20), 'poverty_income_ratio'] = np.nan
    d['education_missing'] = d.education.isna().astype(int)
    d['poverty_missing'] = d.poverty_income_ratio.isna().astype(int)
    d['age_squared'] = d.age ** 2
    for z in ['adult_interviewer', 'family_interviewer']:
        d[z] = d[z].where(d[z] != 8888)
    return d


def model(columns):
    nums = [x for x in NUMERIC if x in columns]
    cats = [x for x in columns if x not in nums]
    transform = ColumnTransformer([
        ('numeric', make_pipeline(SimpleImputer(strategy='median'), StandardScaler()), nums),
        ('categorical', make_pipeline(SimpleImputer(strategy='most_frequent'),
                                      OneHotEncoder(handle_unknown='ignore')), cats)])
    return make_pipeline(transform, LogisticRegression(C=1., max_iter=2000))


def cluster_bootstrap(delta, cluster, seed):
    """Paired conditional-fit interval, not a survey-design confidence interval."""
    g = pd.DataFrame({'delta': delta, 'cluster': cluster}).groupby('cluster').delta.agg(['sum', 'size'])
    rng = np.random.default_rng(seed)
    ids = rng.integers(0, len(g), size=(1500, len(g)))
    draws = g['sum'].to_numpy()[ids].sum(axis=1) / g['size'].to_numpy()[ids].sum(axis=1)
    return np.quantile(draws, [.025, .975]).tolist()


def relevance(d, instrument, cohort):
    d = d.loc[d[instrument].notna()].reset_index(drop=True)
    rows, predictions = [], []
    for mode in ['family', 'family_psu_adjusted', 'psu']:
        groups = d.survey_cluster if mode == 'psu' else d.family
        tr, te = next(GroupShuffleSplit(n_splits=1, train_size=.7, random_state=SEED).split(d, groups=groups))
        columns = NUMERIC + CATEGORICAL + (['survey_cluster'] if mode == 'family_psu_adjusted' else [])
        predictions_by_model = []
        out = {'cohort': cohort, 'instrument': instrument, 'split': mode,
               'n_train': len(tr), 'n_test': len(te),
               'n_train_clusters': int(d.iloc[tr].survey_cluster.nunique()),
               'n_test_clusters': int(d.iloc[te].survey_cluster.nunique()),
               'unseen_interviewer_test_fraction': float((~d.iloc[te][instrument].isin(d.iloc[tr][instrument])).mean())}
        for tag, features in [('x_only', columns), ('x_and_z', columns + [instrument])]:
            fitted = model(features).fit(d.iloc[tr][features], d.iloc[tr].observed)
            p = fitted.predict_proba(d.iloc[te][features])[:, 1]
            y = d.iloc[te].observed.to_numpy()
            predictions_by_model.append(p)
            out[tag + '_log_loss'] = float(log_loss(y, p))
            out[tag + '_brier'] = float(brier_score_loss(y, p))
            out[tag + '_auc'] = float(roc_auc_score(y, p))
        p0, p1 = [np.clip(p, 1e-10, 1-1e-10) for p in predictions_by_model]
        y = d.iloc[te].observed.to_numpy()
        delta = -y*np.log(p0)-(1-y)*np.log(1-p0)+y*np.log(p1)+(1-y)*np.log(1-p1)
        lo, hi = cluster_bootstrap(delta, d.iloc[te].survey_cluster.to_numpy(), SEED)
        out.update(log_loss_improvement=float(delta.mean()),
                   improvement_cluster_bootstrap_lower=lo, improvement_cluster_bootstrap_upper=hi)
        rows.append(out)
        predictions.append(pd.DataFrame({'cohort': cohort, 'instrument': instrument,
            'split': mode, 'row_id': d.iloc[te].row_id.to_numpy(),
            'survey_cluster': d.iloc[te].survey_cluster.to_numpy(), 'observed': y,
            'p_x_only': p0, 'p_x_and_z': p1}))
        print(cohort, instrument, mode, 'heldout log-loss improvement', out['log_loss_improvement'], flush=True)
    return rows, predictions


def native_cohort(d):
    """Outcome/response-blind design sampling and label selection."""
    all_families = np.sort(d.family.unique())
    shuffled = np.random.default_rng(SEED).permutation(all_families)
    design_families = shuffled[:int(np.ceil(.2 * len(all_families)))]
    is_design = d.family.isin(design_families)
    counts = d.loc[is_design & d.adult_interviewer.notna()].groupby('adult_interviewer').size()
    # Stable ties use numeric interviewer identity.
    counts = counts.rename('design_count').reset_index().sort_values(
        ['design_count', 'adult_interviewer'], ascending=[False, True])
    selected = counts.head(5).adult_interviewer.astype(int).tolist()
    prepared = pd.read_csv(BASE/'prepared.csv')
    keep_ids = d.loc[~is_design & d.adult_interviewer.isin(selected), 'row_id']
    cohort = prepared.loc[prepared.row_id.isin(keep_ids)].copy()
    cohort.to_csv(BASE/'prepared_natural.csv', index=False)
    design = d.loc[is_design, ['row_id', 'family', 'adult_interviewer']].copy()
    design.to_csv(BASE/'native_design_holdout.csv', index=False)
    counts.to_csv(BASE/'native_design_arm_counts.csv', index=False)
    metadata = json.loads((BASE/'prepared_metadata.json').read_text())
    metadata['categorical_features'] = [x for x in metadata['categorical_features'] if x != 'survey_cluster']
    metadata.update(rows=len(cohort), observed_rows=int(cohort['observed'].sum()),
        missing_rows=int((~cohort['observed'].astype(bool)).sum()),
        families=int(cohort.household_id.nunique()), interviewers=5,
        native_selection_rule='Five largest adult-interviewer counts in an independent 20% family design sample; no outcomes or response indicators used.',
        native_design_seed=SEED, native_design_family_count=len(design_families),
        native_design_row_count=int(is_design.sum()), native_selected_interviewers=selected,
        native_cohort_rows=len(cohort), native_cohort_families=int(cohort.household_id.nunique()),
        native_design_holdout_excluded=True,
        analysis_target='Empirical adult household-interview cohort with one sampled adult per family, restricted to five design-selected interviewers; not a nationally weighted target.',
        iv_validity='Exploratory candidate interviewer IV; conditional outcome independence is unverified.')
    (BASE/'prepared_natural_metadata.json').write_text(json.dumps(metadata, indent=2))
    audit_cohort = d.loc[d.row_id.isin(keep_ids)].reset_index(drop=True)
    return audit_cohort, metadata


def audit_overlap(native, fine_psu=False):
    features = NUMERIC + CATEGORICAL + (['survey_cluster'] if fine_psu else [])
    tr, te = next(GroupShuffleSplit(n_splits=1, train_size=.7, random_state=SEED).split(native, groups=native.family))
    fitted = model(features).fit(native.iloc[tr][features], native.iloc[tr].adult_interviewer.astype(int))
    p = fitted.predict_proba(native.iloc[te][features])
    labels = fitted[-1].classes_
    zi = np.searchsorted(labels, native.iloc[te].adult_interviewer.astype(int))
    assigned = p[np.arange(len(te)), zi]
    cell = native.phase.astype(str) + ':' + native.region.astype(str)
    counts = pd.crosstab(native.adult_interviewer.astype(int), cell)
    if not fine_psu:
        counts.to_csv(BASE/'native_region_phase_counts.csv')
    psu_counts = pd.crosstab(native.adult_interviewer.astype(int), native.survey_cluster)
    if not fine_psu:
        psu_counts.to_csv(BASE/'native_pseudo_psu_counts.csv')
    return dict(n_holdout=len(te), raw_min_propensity=float(p.min()),
        min_over_arms_quantiles=dict(zip(['q00', 'q01', 'q05', 'q50'], np.quantile(p.min(axis=1), [0, .01, .05, .5]).tolist())),
        assigned_arm_quantiles=dict(zip(['q00', 'q01', 'q05', 'q50'], np.quantile(assigned, [0, .01, .05, .5]).tolist())),
        all_arms_above_002_fraction=float(np.mean(p.min(axis=1) >= .02)),
        all_arms_present_each_region_phase=bool((counts > 0).all().all()),
        region_phase_min_cell_count=int(counts.min().min()),
        native_pseudo_psus=int(len(psu_counts.columns)),
        pseudo_psus_with_all_five_arms=int((psu_counts > 0).all(axis=0).sum()),
        pseudo_psus_with_all_five_arms_at_least_five_adults=int((psu_counts >= 5).all(axis=0).sum()),
        fine_psu_covariate_adjustment=fine_psu,
        note='Regularized multinomial logistic, held-out families, no clipping. Model-based positivity diagnostic only; nonzero predictions do not prove population overlap.')


def main():
    raw = pd.read_csv(BASE/'adult_merged.csv')
    d = frame(raw)
    native, metadata = native_cohort(d)
    # Mirror the primary experiment's fixed one-adult-per-family draw, before
    # its training/calibration/test partitions; never use outcomes to choose.
    shuffle = np.random.default_rng(20260918 + 32771).permutation(len(native))
    _, first = np.unique(native.family.to_numpy()[shuffle], return_index=True)
    native_one = native.iloc[np.sort(shuffle[first])].reset_index(drop=True)
    summary = dict(n_adults=len(d), n_observed=int(d.observed.sum()),
        observation_rate=float(d.observed.mean()), family_count=int(d.family.nunique()),
        pseudo_psu_count=int(d.survey_cluster.nunique()),
        native_selected_interviewers=metadata['native_selected_interviewers'],
        native_n=len(native), native_families=int(native.family.nunique()),
        native_observed=int(native.observed.sum()), native_response_rate=float(native.observed.mean()),
        native_one_per_family_n=len(native_one),
        native_one_per_family_observed=int(native_one.observed.sum()),
        native_one_per_family_response_rate=float(native_one.observed.mean()),
        native_design_seed=SEED, native_design_families=metadata['native_design_family_count'],
        native_design_rows=metadata['native_design_row_count'])
    arm_tables = []
    for instrument in ['adult_interviewer', 'family_interviewer']:
        v = d.loc[d[instrument].notna()]
        counts = v.groupby(instrument).agg(n=('observed', 'size'), observed=('observed', 'sum'),
            response_rate=('observed', 'mean'), regions=('region', 'nunique'), phases=('phase', 'nunique'),
            families=('family', 'nunique'), pseudo_psus=('survey_cluster', 'nunique'))
        counts['max_psu_share'] = v.groupby(instrument).survey_cluster.value_counts(normalize=True).groupby(level=0).max()
        counts = counts.reset_index().rename(columns={instrument: 'interviewer'})
        counts['instrument'] = instrument
        arm_tables.append(counts)
        summary[instrument] = dict(valid_n=len(v), missing_n=int(d[instrument].isna().sum()),
            arms=int(v[instrument].nunique()), arms_below_50=int((counts.n < 50).sum()),
            arms_below_100=int((counts.n < 100).sum()),
            n_in_arms_below_100=int(counts.loc[counts.n < 100, 'n'].sum()),
            arms_in_one_phase=int((counts.phases == 1).sum()),
            response_rate_range_n100=counts.loc[counts.n >= 100, 'response_rate'].agg(['min', 'max']).to_dict())
    arms = pd.concat(arm_tables, ignore_index=True)
    arms.to_csv(BASE/'interviewer_arm_diagnostics.csv', index=False)
    all_rows, all_predictions = [], []
    for instrument in ['adult_interviewer', 'family_interviewer']:
        rows, predictions = relevance(d, instrument, 'all_valid')
        all_rows.extend(rows); all_predictions.extend(predictions)
    rows, predictions = relevance(native, 'adult_interviewer', 'native_five_arms')
    all_rows.extend(rows); all_predictions.extend(predictions)
    rows, predictions = relevance(native_one, 'adult_interviewer', 'native_one_per_family')
    all_rows.extend(rows); all_predictions.extend(predictions)
    result = pd.DataFrame(all_rows)
    result.to_csv(BASE/'relevance_diagnostics.csv', index=False)
    pd.concat(all_predictions, ignore_index=True).to_csv(BASE/'relevance_holdout_predictions.csv', index=False)
    summary['native_overlap'] = audit_overlap(native)
    summary['native_overlap_psu_adjusted'] = audit_overlap(native, fine_psu=True)
    summary['relevance_models'] = all_rows
    summary['relevance_specification'] = dict(numeric=NUMERIC, categorical=CATEGORICAL,
        model='L2 logistic regression C=1; train-only median/scaling/one-hot preprocessing',
        split='70% training families or pseudo-PSUs, 30% holdout, fixed seed',
        bootstrap='1,500 paired pseudo-PSU bootstrap draws on heldout predictions, conditional on fitted models; not a survey-design interval')
    (BASE/'instrument_diagnostics.json').write_text(json.dumps(summary, indent=2))
    make_plot(d, native, arms, result)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['relevance_models']}, indent=2), flush=True)


def make_plot(d, native, arms, relevance_df):
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axs = plt.subplots(2, 2, figsize=(11.5, 8.2), constrained_layout=True)
    axs[0, 0].hist(d.loc[d.observed == 1, 'outcome'], bins=np.arange(4.5, 20, .25),
                   color='#3c7194', alpha=.9)
    axs[0, 0].set(xlabel='Observed hemoglobin (g/dL)', ylabel='Adults',
                   title='A  Real outcome distribution')
    for instrument, color, label in [('adult_interviewer', '#276b9c', 'Adult interviewer'),
                                      ('family_interviewer', '#d07732', 'Family interviewer')]:
        a = arms.loc[(arms.instrument == instrument) & (arms.n >= 50)]
        axs[0, 1].scatter(a.n, a.response_rate, s=23, alpha=.65, color=color, label=label)
    axs[0, 1].axhline(d.observed.mean(), color='black', linestyle=':', linewidth=1)
    axs[0, 1].set(xlabel='Adults per interviewer (at least 50)', ylabel='Hemoglobin observed fraction',
                   title='B  Unadjusted interviewer differences')
    axs[0, 1].legend(frameon=False, fontsize=8)
    sub = relevance_df[relevance_df.cohort == 'all_valid'].copy()
    labels = []
    for i, row in enumerate(sub.itertuples()):
        labels.append(('Adult' if row.instrument == 'adult_interviewer' else 'Family') + '\n' +
                      {'family': 'Family holdout', 'family_psu_adjusted': '+ PSU adjustment', 'psu': 'PSU holdout'}[row.split])
        axs[1, 0].errorbar(i, row.log_loss_improvement,
            yerr=[[row.log_loss_improvement-row.improvement_cluster_bootstrap_lower],
                  [row.improvement_cluster_bootstrap_upper-row.log_loss_improvement]],
            fmt='o', color='#276b9c' if i < 3 else '#d07732', capsize=3)
    axs[1, 0].axhline(0, color='black', linewidth=1, linestyle=':')
    axs[1, 0].set(xticks=np.arange(len(labels)), xticklabels=labels,
                  ylabel='Heldout log-loss improvement with interviewer',
                  title='C  Adjusted relevance (higher is better)')
    axs[1, 0].tick_params(axis='x', labelsize=7)
    cross = pd.crosstab(native.adult_interviewer.astype(int),
        native.phase.astype(int).astype(str) + ':' + native.region.astype(int).astype(str))
    im = axs[1, 1].imshow(cross.to_numpy(), cmap='Blues', aspect='auto')
    axs[1, 1].set(xticks=np.arange(len(cross.columns)), xticklabels=cross.columns,
                  yticks=np.arange(len(cross)), yticklabels=cross.index,
                  xlabel='Survey phase : Census region', ylabel='Frozen adult interviewer IDs',
                  title='D  Native-cohort support (adult counts)')
    for i in range(len(cross)):
        for j in range(len(cross.columns)):
            value = cross.iloc[i, j]
            axs[1, 1].text(j, i, str(value), ha='center', va='center', fontsize=8,
                          color='white' if value > .6*cross.to_numpy().max() else 'black')
    fig.colorbar(im, ax=axs[1, 1], shrink=.8)
    out = BASE.parent.parent/'figures'
    out.mkdir(exist_ok=True)
    for ext in ['png', 'pdf']:
        fig.savefig(out/f'nhanes_data_diagnostics.{ext}', dpi=180)
    plt.close(fig)


if __name__ == '__main__':
    main()
