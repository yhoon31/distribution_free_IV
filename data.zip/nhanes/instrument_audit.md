# NHANES III candidate interviewer-instrument audit

The released interviewer identities predict hemoglobin availability modestly
after demographic adjustment. This does **not** establish the instrument
condition `Z independent of Y given X`. The native analysis is an exploratory
application with weak conditional relevance, limited overlap, unknown outcomes
for nonrespondents, and a complex survey design. Controlled masking of observed
hemoglobin supplies the experiment in which coverage can actually be measured.

## Data interpretation

CDC identifies `HAINTVR` as the adult household interviewer, `HFINTVR` as the
family interviewer, and `8888` as a missing identifier. `DMPFSEQ` links families;
different families may occupy one dwelling. Public `SDPSTRA6` and `SDPPSU6`
define 49 pseudo-strata with two variance units each, rather than unrestricted
geographic identifiers. See the [adult codebook, pages 30, 72, 150, and
394](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/ADULT-acc.pdf).

Hemoglobin `HGP` is in g/dL; the documented observed range is 4.95--19.6 and
`88888`/blanks are missing. Venipuncture excludes reported hemophilia or recent
chemotherapy. Those exam-stage records are retained as missing outcomes, not
classified as refusals or used to condition eligibility. See the [laboratory
codebook, pages 27, 70, 118--119](https://wwwn.cdc.gov/nchs/data/nhanes3/1a/lab-acc.pdf).

The adult left join has 20,050 records, 17,170 valid hemoglobin measurements,
12,872 families, and 98 public pseudo-PSUs. The primary file retains 19,508 adults
with a known adult interviewer, of whom 16,725 have measured hemoglobin. No
clinical trimming or outcome imputation is applied.

## Arm sizes and support

| Candidate | Valid identities | Distinct arms | Missing identities | Arms below 100 adults | Arms in only one phase |
|---|---:|---:|---:|---:|---:|
| Adult interviewer | 19,508 | 87 | 542 | 40 | 56 |
| Family interviewer | 19,855 | 86 | 195 | 38 | 53 |

Among arms with at least 100 adults, raw hemoglobin observation rates span
62.31--95.77% for adult and 64.39--93.93% for family interviewers. These rates
reflect differences in respondent mix as well as possible interviewer effects.
They do not show conditional relevance by themselves.

Using all 87 adult arms would require estimating an observation subdensity for
many very small strata. Therefore a separate, outcome-blind design sample of
20% of families is frozen using seed 20262515. It contains 2,575 families and
4,032 adults. The five largest **design-sample adult-interviewer counts** select
IDs 7020, 7067, 7024, 7016, and 7005, with ties broken by numeric ID. The entire
design sample is excluded from native model fitting, calibration, and testing.
Neither availability nor hemoglobin is used to select the identities.

`prepared_natural.csv` contains the 3,258 remaining adults interviewed by these
five identities: 2,144 families and 2,810 measured hemoglobins (86.25%). The
primary runner's outcome-blind one-adult-per-family draw leaves 2,144 records,
1,825 measured (85.12%), with seed 20260918 + 32771. The pre-sampling arm sizes
are 555, 637, 853, 623, and 590 in increasing ID order; after family sampling,
they are 413, 365, 578, 374, and 414. This retains adequate data for five fitted
subdensities without choosing arms based on apparent favorable results.

All five identities occur in all eight phase-by-Census-region cells, with a
minimum of 12 adults per cell. Fine support is substantially weaker: only 6 of
the 96 represented pseudo-PSUs contain all five identities, and only 2 have at
least five adults from each. These are empirical sparsity diagnostics, not
proof that an absent cell has structural zero probability.

## Held-out conditional relevance

We compare two L2 logistic models for `R`, with `C=1`: covariates alone versus
the same covariates plus categorical interviewer identity. Covariates are age,
age squared, education, poverty-income ratio, sex, race/ethnicity, interview
language, Census region, urbanicity, survey phase, and missingness indicators
for education and income. Median imputation, scaling, and one-hot encoding are
fitted only on the training split. This audit uses somewhat richer adjustment
than the primary prediction experiment. There is no tuning to held-out results.

The first split trains on 70% of families and tests on the remaining 30%; the
second adds public pseudo-PSU indicators to the same family split; the third
holds out 30% of pseudo-PSUs entirely. Positive change below means that adding
interviewer identity improves held-out log loss. Brackets give paired 95%
percentile intervals from 1,500 resamples of held-out pseudo-PSUs, conditional
on the fitted models. They are descriptive sensitivity intervals, not
survey-design or unconditional model-training confidence intervals.

| Cohort / interviewer | Family holdout | Family holdout + PSU adjustment | PSU holdout |
|---|---:|---:|---:|
| All valid adult identities | 0.00506 [0.00097, 0.00948] | 0.00351 [-0.00112, 0.00847] | 0.00219 [-0.00212, 0.00621] |
| All valid family identities | 0.00544 [0.00168, 0.00928] | 0.00416 [0.00042, 0.00792] | 0.00222 [-0.00142, 0.00567] |
| Five frozen adult identities, before family sampling | -0.00559 [-0.01178, 0.00025] | -0.00392 [-0.01004, 0.00178] | -0.00022 [-0.00558, 0.00539] |

For all valid adult identities, adding interviewer raises held-out AUC from
0.6446 to 0.6680. Most interviewers in the PSU-held-out test sample also occur
in training; unseen-arm test fractions are only 0.053% (adult) and 0.070%
(family). Consequently, the diminished PSU-held-out gain is not primarily
caused by previously unseen labels.

The count-selected five-arm cohort has **no demonstrated improvement in
conditional availability prediction**. This remains true after applying the
primary one-adult-per-family sampling: log-loss changes are -0.00376,
-0.00308, and -0.000083 for the three split designs. We retain the frozen
selection and report this negative result; we do not search other arm subsets
to improve relevance after inspecting the outcomes.

## Estimated assignment overlap

A separate regularized multinomial logistic model predicts the five selected
interviewer labels from the same covariates, using the family-disjoint
70/30 split of the 3,258-adult native cohort. Probabilities are not floored or
clipped in this audit. On its 961 held-out adults, the minimum probability
across five arms has median 0.04177, fifth percentile 0.00137, and minimum
0.000508. Only 70.55% have all five predicted probabilities at least 0.02.
The actual assigned-arm probability has median 0.3168 and fifth percentile
0.07154; looking only at this probability would conceal poor support for
counterfactual interviewer arms.

Adding pseudo-PSU indicators lowers the median minimum-arm probability to
0.01603; only 41.42% of held-out adults then have all five probabilities at
least 0.02. Regularization makes even empty empirical cells predict positive
probabilities, so these figures cannot certify positivity. Any prediction
procedure's propensity floor stabilizes estimation but does not supply missing
overlap or establish its theoretical assumptions.

## Consequences for interpretation

Interviewer assignment can follow geography, language, fieldwork schedules,
and household characteristics. The available covariates cannot rule out
remaining association with latent hemoglobin. In addition, conditioning on
participation in the initial household interview can itself associate
interviewer and health. Separation between household interviewing and blood
measurement makes a direct measurement effect less likely, but cannot establish
conditional independence. Association between observed hemoglobin and
interviewer among `R=1` would also be an invalid general test of the IV
condition, since conditioning on availability can create such association.

Native intervals should therefore be read as a stress test under a candidate
instrument and estimated nuisances. Native population coverage is unknown;
report observed-outcome coverage and missing-outcome bounds separately. Finite
intervals do not empirically validate the IV assumptions. Infinite intervals
can be an appropriate response to incomplete identification or weak estimated
information and must remain in the reported length summaries.

The calculations are unweighted experiments conditional on the released
cohort, with one sampled adult per family in primary prediction analyses.
They are not prevalence estimates or guarantees for the U.S. population.
Family disjointness does not remove between-family cluster dependence. The
separate pseudo-PSU-disjoint controlled-masking experiment addresses sensitivity
to sharing public survey clusters; it also changes the empirical split and
should not be described as an exact correction for the full survey design.

## Reproduction and outputs

Run `python experiments/data/nhanes/audit_instrument.py` after
`prepare_nhanes.py`. The script writes:

- `prepared_natural.csv` and `prepared_natural_metadata.json`: frozen native cohort.
- `native_design_holdout.csv` and `native_design_arm_counts.csv`: outcome-blind selection audit.
- `interviewer_arm_diagnostics.csv`: counts, missingness, broad support, cluster concentration.
- `relevance_diagnostics.csv` and `relevance_holdout_predictions.csv`: reproducible held-out model results.
- `instrument_diagnostics.json`: all summary values, overlap quantiles, and model specifications.
- `native_region_phase_counts.csv` and `native_pseudo_psu_counts.csv`: raw overlap cells.
- `../../figures/nhanes_data_diagnostics.pdf` and `.png`: outcome, availability, relevance, and broad support.

The prose above describes the saved primary run; CSV/JSON files retain
unrounded results. The design-sample exclusion, source-row uniqueness, and
family counts were checked directly. The plotted diagnostic panels were
visually inspected.
