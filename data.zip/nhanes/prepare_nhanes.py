"""Download and prepare the CDC NHANES III public adult/laboratory files.

Run from the project root: python experiments/data/nhanes/prepare_nhanes.py
All original files are retained. Column locations come from CDC's SAS INPUT
statements, not a manually inferred layout. Missing hemoglobin stays missing.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SOURCE_BASE = "https://wwwn.cdc.gov/nchs/data/nhanes3/1a/"
SOURCE_FILES = ("adult.dat", "lab.dat", "adult.sas", "lab.sas",
                "ADULT-acc.pdf", "lab-acc.pdf")
ADULT_FIELDS = [
    "SEQN", "DMPFSEQ", "DMPSTAT", "DMARETHN", "DMARACER", "DMAETHNR",
    "HSSEX", "HSDOIMO", "HSAGEIR", "HSAGEU", "HSFSIZER", "HSHSIZER",
    "DMPCNTYR", "DMPFIPSR", "DMPMETRO", "DMPCREGN", "DMPPIR",
    "SDPPHASE", "SDPSTRA6", "SDPPSU6", "WTPFQX6", "WTPFEX6",
    "HAINTVR", "HFINTVR", "HALANG", "HFLANG", "HFA8R", "HFA6XCR",
]
LAB_FIELDS = ["SEQN", "HGP", "HGPSI", "PHPHEMO", "PHPCHM2"]


def download_sources():
    """Download only missing originals, then verify cached originals by hash."""
    import requests

    HERE.mkdir(parents=True, exist_ok=True)
    manifest_path = HERE / "manifest.json"
    previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}

    def retrieve(name):
        path = HERE / name
        if not path.exists():
            response = requests.get(SOURCE_BASE + name, timeout=180)
            response.raise_for_status()
            content = response.content
            if (name.endswith(".pdf") and not content.startswith(b"%PDF")) or \
                    b"<!DOCTYPE html" in content[:1000] or b"<html" in content[:1000]:
                raise ValueError(f"CDC returned an unexpected document for {name}")
            path.write_bytes(content)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        recorded = previous.get("files", {}).get(name)
        if recorded and recorded["sha256"] != digest:
            raise ValueError(f"Original source checksum changed: {name}")
        return name, {"url": SOURCE_BASE + name, "bytes": path.stat().st_size,
                      "sha256": digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        files = dict(pool.map(retrieve, SOURCE_FILES))
    manifest = {"first_retrieved_utc": previous.get("first_retrieved_utc",
                 datetime.now(timezone.utc).isoformat()),
                "provider": "US CDC/NCHS", "files": files}
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def read_fixed_width(stem, fields):
    """Read SAS column-input fields; FORMAT controls display, not input scaling.

    HGP contains explicit decimal points in the released ASCII. Applying the
    display FORMAT 8.2 as an implied division by 100 would corrupt the outcome.
    """
    sas = (HERE / f"{stem}.sas").read_text(encoding="ascii")
    input_match = re.search(r"\bINPUT\s+(.*?);", sas, re.S)
    if input_match is None:
        raise ValueError("No SAS INPUT statement found")
    columns = {name: (int(lo)-1, int(hi or lo)) for name, lo, hi in
               re.findall(r"^\s*(\w+)\s+(\d+)(?:-(\d+))?\s*$",
                          input_match.group(1), re.M)}
    labels = dict(re.findall(r'^\s*(\w+)\s*=\s*"([^"]*)"', sas, re.M))
    raw = pd.read_fwf(HERE / f"{stem}.dat", names=fields,
                      colspecs=[columns[name] for name in fields], dtype=str,
                      keep_default_na=False)
    frame = pd.DataFrame({name: pd.to_numeric(raw[name].str.strip().replace(
        {"": np.nan, ".": np.nan}), errors="raise") for name in fields})
    if frame.SEQN.isna().any() or frame.SEQN.duplicated().any():
        raise ValueError(f"Nonunique or missing SEQN in {stem}")
    mapping = {name: {"file": f"{stem}.dat", "first_column_1based": columns[name][0]+1,
                      "last_column_1based_inclusive": columns[name][1],
                      "label": labels[name], "input_scaling": "none; explicit decimal"}
               for name in fields}
    return frame, mapping


def category(values, allowed, missing=None):
    missing = missing or {}
    other = set(values.dropna().unique()) - set(allowed) - set(missing)
    if other:
        raise ValueError(f"Unrecognized codes in {values.name}: {other}")
    return values.map(lambda x: "missing_blank" if pd.isna(x) else
                      missing.get(x, str(int(x))))


def prepare():
    download_sources()
    adult, adult_map = read_fixed_width("adult", ADULT_FIELDS)
    lab, lab_map = read_fixed_width("lab", LAB_FIELDS)
    assert len(adult) == 20050 and len(lab) == 29314
    assert adult.HSAGEIR.between(17, 90).all() and adult.HSAGEU.eq(2).all()
    assert adult.DMPFSEQ.notna().all()
    assert adult.HAINTVR.eq(8888).sum() == 542
    assert adult.HFINTVR.eq(8888).sum() == 195
    assert lab.HGP.eq(88888).sum() == 2914 and lab.HGP.isna().sum() == 28
    valid_hgp = lab.HGP.notna() & lab.HGP.ne(88888)
    assert valid_hgp.sum() == 26372
    assert lab.loc[valid_hgp, "HGP"].between(4.95, 19.6).all()
    assert np.allclose(lab.loc[valid_hgp, "HGPSI"],
                       10 * lab.loc[valid_hgp, "HGP"])
    merged = adult.merge(lab, how="left", on="SEQN", validate="one_to_one",
                         indicator="lab_link")
    assert len(merged) == len(adult)
    merged["outcome"] = merged.HGP.mask(merged.HGP.eq(88888))
    merged["observed"] = merged.outcome.notna().astype(int)
    merged["measurement_status"] = np.select(
        [merged.lab_link.eq("left_only"), merged.HGP.eq(88888), merged.HGP.isna()],
        ["no_lab_record", "lab_blank_applicable", "lab_blank"], default="observed")
    merged["adult_interviewer"] = merged.HAINTVR.mask(merged.HAINTVR.eq(8888))
    merged["family_interviewer"] = merged.HFINTVR.mask(merged.HFINTVR.eq(8888))
    merged["instrument"] = merged.adult_interviewer
    merged["row_id"] = merged.SEQN.astype(int)
    # This is a family identifier, not a dwelling identifier: preserve that
    # distinction in metadata and reporting even though the runner's API calls
    # its split-group column household_id.
    merged["household_id"] = merged.DMPFSEQ.astype(int)
    merged["family_id"] = merged.DMPFSEQ.astype(int)
    merged["age"] = merged.HSAGEIR.astype(int)  # 90 means 90+, per CDC
    merged["sex"] = category(merged.HSSEX, [1, 2])
    merged["race_ethnicity"] = category(merged.DMARETHN, [1, 2, 3, 4])
    merged["education_status"] = np.select(
        [merged.HFA8R.eq(88), merged.HFA8R.eq(99), merged.HFA8R.isna()],
        ["blank_applicable", "dont_know", "missing_blank"], default="observed")
    missing_education = merged.education_status.ne("observed")
    assert merged.loc[~missing_education, "HFA8R"].between(0, 17).all()
    # Fixed zero placeholder + missingness/status feature; no sample-wide
    # imputation estimation, and no sentinel is used as years of education.
    merged["education"] = merged.HFA8R.mask(missing_education, 0).astype(int)
    merged["education_missing"] = missing_education.astype(int)
    merged["interview_language"] = category(merged.HALANG, [1, 2, 3],
                                              {8: "blank_applicable"})
    merged["family_language"] = category(merged.HFLANG, [1, 2, 3],
                                           {8: "blank_applicable"})
    merged["birth_country"] = category(merged.HFA6XCR, [1, 2, 3],
                                        {8: "blank_applicable", 9: "dont_know"})
    for alias, raw, allowed in [
            ("region", "DMPCREGN", range(1, 5)), ("urban", "DMPMETRO", [1, 2]),
            ("phase", "SDPPHASE", [1, 2]), ("pseudo_stratum", "SDPSTRA6", range(1, 50)),
            ("pseudo_psu", "SDPPSU6", [1, 2])]:
        merged[alias] = category(merged[raw], allowed)
    merged["survey_cluster"] = merged.pseudo_stratum + ":" + merged.pseudo_psu
    merged["cluster_id"] = merged.survey_cluster
    merged["interview_weight"] = merged.WTPFQX6
    merged.to_csv(HERE / "adult_merged.csv", index=False)
    prepared = merged.loc[merged.adult_interviewer.notna()].copy()
    prepared["instrument"] = prepared.instrument.astype(int)
    assert len(prepared) == 19508
    prepared.to_csv(HERE / "prepared.csv", index=False)
    meta = {
        "dataset": "NHANES III adults with valid adult interviewer identity",
        "source": "CDC/NCHS NHANES III, 1988-1994, core release 1A",
        "numeric_features": ["age", "education", "education_missing"],
        "categorical_features": ["sex", "race_ethnicity", "education_status",
                                 "interview_language", "region", "urban", "phase"],
        "instrument_type": "categorical", "instrument": "HAINTVR adult household interviewer",
        "outcome": "HGP hemoglobin concentration", "outcome_units": "g/dL",
        "observed": "valid HGP after adult-file left join to laboratory file",
        "cluster": "DMPFSEQ public family sequence (runner column household_id)",
        "sampling_unit": "family", "primary_tail_trimming": False,
        "natural_target": "Interviewed adults aged 17+ with known HAINTVR, including unmeasured hemoglobin",
        "benchmark_target": "Adults in this cohort with observed HGP; artificial masking only",
        "survey_weighting": "Unweighted experimental sample; not nationally representative inference",
        "rows": len(prepared), "observed_rows": int(prepared.observed.sum()),
        "missing_rows": int((1-prepared.observed).sum()),
        "families": int(prepared.family_id.nunique()),
        "interviewers": int(prepared.instrument.nunique()),
        "missing_covariates": "Education fixed zero placeholder plus explicit indicator/status; categorical missing codes explicit",
        "family_limitation": "DMPFSEQ links families; distinct families can occupy the same dwelling",
        "survey_design_sensitivity": "cluster_id = survey_cluster = SDPSTRA6:SDPPSU6; retained for diagnostics and sensitivity, not default predictors or precise geography",
        "age_topcoding": "HSAGEIR=90 denotes age 90+",
    }
    (HERE / "prepared_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    summary = {
        "adult_source_rows": len(adult), "laboratory_source_rows_all_ages": len(lab),
        "adult_left_join_rows": len(merged), "adult_families": int(merged.family_id.nunique()),
        "adult_measurement_status": merged.measurement_status.value_counts().to_dict(),
        "adult_exam_status": merged.DMPSTAT.value_counts().sort_index().to_dict(),
        "adult_missing_interviewer": int(merged.adult_interviewer.isna().sum()),
        "family_missing_interviewer": int(merged.family_interviewer.isna().sum()),
        "adult_distinct_interviewers": int(merged.adult_interviewer.nunique()),
        "family_distinct_interviewers": int(merged.family_interviewer.nunique()),
        "prepared_rows": len(prepared), "prepared_families": int(prepared.family_id.nunique()),
        "prepared_observed": int(prepared.observed.sum()),
        "prepared_missing": int((1-prepared.observed).sum()),
        "prepared_observation_rate": float(prepared.observed.mean()),
        "prepared_measurement_status": prepared.measurement_status.value_counts().to_dict(),
        "prepared_education_status": prepared.education_status.value_counts().to_dict(),
        "prepared_interview_language": prepared.interview_language.value_counts().to_dict(),
        "prepared_outcome_summary": prepared.outcome.describe().to_dict(),
        "raw_medical_exclusions": {"hemophilia_yes": int(merged.PHPHEMO.eq(1).sum()),
                                   "recent_chemotherapy_yes": int(merged.PHPCHM2.eq(1).sum())},
    }
    (HERE / "sample_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (HERE / "codebook_mapping.json").write_text(
        json.dumps({"adult": adult_map, "laboratory": lab_map}, indent=2), encoding="utf-8")
    pd.DataFrame([
        ("All household adult records", len(merged)),
        ("Exclude unavailable HAINTVR=8888", int(merged.adult_interviewer.isna().sum())),
        ("Primary prepared cohort", len(prepared)),
        ("Of primary: valid hemoglobin", int(prepared.observed.sum())),
        ("Of primary: unknown hemoglobin retained", int((1-prepared.observed).sum())),
    ], columns=["stage", "n"]).to_csv(HERE / "cohort_flow.csv", index=False)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    prepare()
