	Codes for Arellano and Bonhomme, "Quantile Selection Models", to appear in Econometrica

			Readme file



The codes are written in Stata and matlab
The paths (such as "C\Dfile\...") need to be modified


The dataset is constructed using Sampleconstruction.do 

Table 1 is constructed based on data_1.dta and data_2.dta, which are obtained from Sampleconstruction.do  

Copula parameters of the Frank copula are computed in Estimation_rho.m

Quantile parameters are computed and wage quantiles and participation are simulated in Estimation_beta.m

As a result of Estimation_beta.m, Matres_m.txt and Matres_f.txt are generated. 

Graphs_latent.do then produces Figure 1

Graphs_fit.do produces Figure 2

Graphs_Frank_copula.m and Graphs_GeneralizedFrank.m produce Figure 3

Copula parameters of the generalized Frank copula are computed in Estimation_rho_GeneralizedFrank.m
 
Quantile parameters are computed based on the generalized Frank, and wage quantiles and participation are simulated in Estimation_beta_GeneralizedFrank.m

Graphs_latent (by un-commenting a few lines of code) then produces Figure 4 

Subsampling (for the Frank specification) is performed in Subsampling_confidence_intervals.m

Estimation_beta_bounds.m computes the bounds, and Graphs_bounds.do and Graphs_bounds_education.do produce Figure 5

Sample_construction_GE constructs the sample to be used in the equilibrium analysis in Section 4.3

Estimation_GE.m computes the equilibrium in the counterfactual

Graphs_GE.do then produces Figures 6,7,8 and the figures in the supplementary appendix.


The codes make use of Morillo, Koenker and Eilers' rq.m routine, which is included in the replication files.


Lastly, the folder "Generic_code" contains a matlab code Code_QRS.m to be used in any empirical application. 

That code performs quantile regression with sample selecton (QRS), based on arbitrary input. It also makes use of rq.m

Feel free to use it!


