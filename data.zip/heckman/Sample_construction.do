/* Stata code for Arellano and Bonhomme, "Quantile Selection Models" */
/* This code constructs the dataset */
/* It is based on part of par_boot.do written in Blundell et al (2007, Econometrica) */
/* It uses wagedata.dta */

/* The code also estimates the parameters of the propensity score (first step of estimation) */
/* as well as the suppremum of the support of the propensity score (for bounds calculations) */

clear matrix

set matsize 400
set trace off
set seed 2
clear
set mem 500m
set more 1

cd C:\Dfile\Dossiers\Textes\Quantiles\Codes\Quantiles_stata

* loop on gender

* loop on gender
local gender=1
while `gender'<=2{

* SINGLES 

** first clean up raw data
u wagedata, clear

* clean wage
replace wage = . if work==0 |wage==0
gen x = wage==.
so x sex year wage
qui by x sex year : replace wage=. if _n<10 |_N-_n<10
gen lw = log(wage)

* drop missing observations
drop if work==1 & lw==.

* keep males
keep if sex==`gender'

* drop self-employed
drop if self==1

* create variables

* out-of work income
replace ben_inc = . if ben_inc<=0
replace ben_inc = log(ben_inc)

gen s_zero=(1-couple)*ben_inc
replace s_zero=0 if ben_inc==.

gen m_zero=couple*ben_inc
replace m_zero=0 if ben_inc==.

gen No_zero=(ben_inc==.)

* marital status
gen married=couple

* keep singles
keep if married==0

* keep if education is reported
keep if educ~=.

* keep if instruments are available
keep if No_zero==0
drop No_zero

* trends
gen trend1=year-77
gen trend2=trend1^2
gen trend3=trend1^3

* cohort
gen cohort=year+1900-age
gen c1919_34=(cohort>=1919)*(cohort<=1934)
gen c1935_44=(cohort>=1935)*(cohort<=1944)
gen c1955_64=(cohort>=1955)*(cohort<=1964)
gen c1965_77=(cohort>=1965)*(cohort<=1977)


* region
local j=1
while `j'<=11{
gen reg_d`j'=(region==`j')
local j=`j'+1
}

* kids
gen kids_d1=kids1
gen kids_d2=kids2
gen kids_d3=kids34
gen kids_d4=kids510
gen kids_d5=kids1116
gen kids_d6=kids1718

drop index

* participation probit
probit work s_zero ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d*


predict pZ
predict index, xb
matrix eb=e(b)

* Sup (propensity score)
* Un-comment in order to use the trimmed estimator
qui  _pctile s_zero, p(1)
scalar mininst=r(r1)

* Un-comment in order to use the un-trimmed estimator
*qui su s_zero
*scalar mininst=r(min)

gen indextilde=index+(eb[1,1]*mininst)-(eb[1,1]*s_zero)
gen suppZ=normal(indextilde)

* Replace lower values of the sup (propensity score)
_pctile suppZ, p(1)
replace suppZ=r(r1) if suppZ<r(r1)


drop index indextilde




* save dataset

keep married lw work pZ suppZ ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d* year
order married lw work pZ suppZ ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d* year
saveold data_`gender', replace


* MARRIED 

** first clean up raw data
u wagedata, clear

* clean wage
replace wage = . if work==0 |wage==0
gen x = wage==.
so x sex year wage
qui by x sex year : replace wage=. if _n<10 |_N-_n<10
gen lw = log(wage)

* drop missing observations
drop if work==1 & lw==.

* keep males
keep if sex==`gender'

* drop self-employed
drop if self==1

* create variables

* out-of work income
replace ben_inc = . if ben_inc<=0
replace ben_inc = log(ben_inc)

gen s_zero=(1-couple)*ben_inc
replace s_zero=0 if ben_inc==.

gen m_zero=couple*ben_inc
replace m_zero=0 if ben_inc==.

gen No_zero=(ben_inc==.)

* marital status
gen married=couple

* keep married
keep if married==1

* keep if education is reported
keep if educ~=.

* keep if instruments are available
keep if No_zero==0
drop No_zero

* trends
gen trend1=year-77
gen trend2=trend1^2
gen trend3=trend1^3

* cohort
gen cohort=year+1900-age
gen c1919_34=(cohort>=1919)*(cohort<=1934)
gen c1935_44=(cohort>=1935)*(cohort<=1944)
gen c1955_64=(cohort>=1955)*(cohort<=1964)
gen c1965_77=(cohort>=1965)*(cohort<=1977)


* region
local j=1
while `j'<=11{
gen reg_d`j'=(region==`j')
local j=`j'+1
}

* kids
gen kids_d1=kids1
gen kids_d2=kids2
gen kids_d3=kids34
gen kids_d4=kids510
gen kids_d5=kids1116
gen kids_d6=kids1718

drop index

* participation probit
probit work m_zero ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d*

predict pZ
predict index, xb
matrix eb=e(b)


* Sup (propensity score)
* Un-comment in order to use the trimmed estimator
qui  _pctile m_zero, p(1)
scalar mininst=r(r1)

* Un-comment in order to use the un-trimmed estimator
*qui su m_zero
*scalar mininst=r(min)


gen indextilde=index+(eb[1,1]*mininst)-(eb[1,1]*m_zero)
gen suppZ=normal(indextilde)

* Replace lower values of the sup (propensity score)
_pctile suppZ, p(1)
replace suppZ=r(r1) if suppZ<r(r1)

drop index indextilde


* save dataset

keep married lw work pZ suppZ ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d* year
order  married lw work pZ suppZ ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d* year
append using data_`gender'
save data_`gender', replace

outsheet  married lw work pZ suppZ ed17 ed18 trend1 trend2 trend3 c1919_34 c1935_44 c1955_64 c1965_77 /*
*/ reg_d* kids_d* year using data_`gender', comma replace

local gender=`gender'+1
}
