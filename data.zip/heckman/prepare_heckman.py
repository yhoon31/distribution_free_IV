"""Prepare the public Arellano--Bonhomme (2017) FES replication data.

Run from any directory: python experiments/data/heckman/prepare_heckman.py
The downloaded original archive is retained unchanged. This implements the
sample-selection portion of the authors' Sample_construction.do, not their
estimation code. pandas can read the exported CSV without pyreadstat.
"""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ARCHIVE_URL = (
    "https://drive.usercontent.google.com/download?"
    "id=0B13ohL0_ULTDMVhBN0s1OXhldWc&export=download&authuser=0&confirm=t"
    "&resourcekey=0-dIhzC3g5wMpbtap-CnHhSw"
)


def prepare():
    archive = HERE / "Codes_for_replication.zip"
    if not archive.exists():
        import requests
        response = requests.get(ARCHIVE_URL, timeout=180)
        response.raise_for_status()
        if not response.content.startswith(b"PK"):
            raise RuntimeError("Public archive endpoint did not return a ZIP file")
        archive.write_bytes(response.content)
    with zipfile.ZipFile(archive) as z:
        for name in (
            "Data_files/wagedata.dta", "Stata_codes/Sample_construction.do", "Readme.txt"
        ):
            (HERE / Path(name).name).write_bytes(z.read("Codes_for_replication/" + name))
    raw_csv = HERE / "wagedata.csv"
    if not raw_csv.exists():
        # Original DTA uses Stata version 110, unsupported by pandas.
        sys.path.append(str(HERE.parents[1]))
        from runtime_support import ensure_vendor
        sys.path.append(str(ensure_vendor()))
        import pyreadstat
        raw, meta = pyreadstat.read_dta(HERE / "wagedata.dta")
        raw.to_csv(raw_csv, index=False)
        (HERE / "variable_labels.json").write_text(
            json.dumps(meta.column_names_to_labels, indent=2), encoding="utf-8"
        )
    d = pd.read_csv(raw_csv)
    for column in d:
        d[column] = pd.to_numeric(d[column], errors="raise")
    counts = {"raw_rows": len(d)}
    d.insert(0, "source_row", np.arange(len(d)))

    # Exactly the original code's order: declare wages missing for nonworkers
    # or zero wages, then trim first 9 and last 10 valid wages within sex/year.
    d.loc[(d.work == 0) | (d.wage == 0), "wage"] = np.nan
    primary = d.copy()
    valid = d[d.wage.notna()].sort_values(
        ["sex", "year", "wage", "source_row"], kind="stable"
    )
    group = valid.groupby(["sex", "year"], sort=False)
    rank = group.cumcount() + 1
    size = group["source_row"].transform("size")
    trim_ids = valid.loc[(rank < 10) | ((size - rank) < 10), "source_row"]
    counts["wage_tail_rows_trimmed"] = len(trim_ids)
    primary = primary[(primary.self != 1) & primary.educ.notna() &
                      (primary.ben_inc > 0) &
                      ((primary.work == 0) | (primary.wage > 0))].copy()
    primary["author_trimmed"] = primary.source_row.isin(trim_ids).astype(int)
    primary["y"] = np.log(primary.wage)
    d.loc[d.source_row.isin(trim_ids), "wage"] = np.nan
    d["y"] = np.log(d.wage)
    d = d[~((d.work == 1) & d.y.isna())].copy()
    counts["after_worker_wage_cleaning"] = len(d)
    d = d[d.self != 1].copy()
    counts["after_self_employment_exclusion"] = len(d)
    d = d[d.educ.notna() & (d.ben_inc > 0)].copy()
    counts["final_all"] = len(d)
    counts["final_by_sex"] = d.groupby("sex").size().to_dict()
    # Full-time education / age 23--59 restrictions already occur in supplied
    # wagedata.dta, matching the paper. Do not add an invented age restriction.
    assert d.age.between(23, 59).all()
    assert np.array_equal(d.y.notna().to_numpy(), (d.work == 1).to_numpy())
    for sample in (d, primary):
        sample["r"] = sample.work.astype(int)
        sample["z_cont"] = np.log(sample.ben_inc)
        sample["calendar_year"] = 1900 + sample.year
        sample["cohort"] = sample.calendar_year - sample.age
        sample["trend"] = sample.year - 77
        sample["cluster_id"] = (sample.year.astype(int).astype(str) + "_" +
                                sample.hhref.astype(int).astype(str))
        sample["household_id"] = sample.cluster_id
        for label, lo, hi in [("c1919_34", 1919, 1934), ("c1935_44", 1935, 1944),
                               ("c1955_64", 1955, 1964), ("c1965_77", 1965, 1977)]:
            sample[label] = sample.cohort.between(lo, hi).astype(int)
    keep = ["source_row", "cluster_id", "household_id", "calendar_year", "year", "trend", "age",
            "sex", "couple", "educ", "ed16", "ed17", "ed18", "region",
            "numhhkid", "kids1", "kids2", "kids34", "kids510", "kids1116",
            "kids1718", "cohort", "c1919_34", "c1935_44", "c1955_64",
            "c1965_77", "ben_inc", "z_cont", "r", "wage", "y"]
    clean = d[keep].sort_values("source_row")
    clean.to_csv(HERE / "fes_clean.csv", index=False)
    single = clean[(clean.sex == 1) & (clean.couple == 0)].copy()
    single.to_csv(HERE / "fes_single_men.csv", index=False)
    counts["single_men"] = len(single)
    counts["single_men_observed"] = int(single.r.sum())
    counts["single_men_missing"] = int((1 - single.r).sum())
    counts["single_men_households"] = single.cluster_id.nunique()
    counts["single_men_log_wage_summary"] = single.y.describe().to_dict()
    counts["single_men_instrument_summary"] = single.z_cont.describe().to_dict()
    primary_single = primary[(primary.sex == 1) & (primary.couple == 0)][
        keep + ["author_trimmed"]].sort_values("source_row")
    for new, original in {"outcome": "y", "observed": "r", "instrument": "z_cont",
                          "row_id": "source_row"}.items():
        primary_single[new] = primary_single[original]
    primary_single.to_csv(HERE / "prepared.csv", index=False)
    metadata = {
        "dataset": "FES single men", "source": "Arellano and Bonhomme (2017)",
        "numeric_features": ["age", "ed17", "ed18", "calendar_year", "kids1", "kids2",
                             "kids34", "kids510", "kids1116", "kids1718"],
        "categorical_features": ["region"], "instrument_type": "continuous",
        "outcome": "Natural logarithm of hourly wage in the authors' real-wage units",
        "outcome_units": "log hourly wage", "instrument": "log potential out-of-work benefit income",
        "observed": "work == 1", "cluster": "year + hhref (household)",
        "natural_target": "Latent hourly wages of single men aged 23--59, including nonworkers",
        "benchmark_target": "Observed employed single men; artificial masking only",
        "primary_tail_trimming": False, "author_trimmed_column": "author_trimmed",
        "rows": len(primary_single), "observed_rows": int(primary_single.r.sum()),
        "missing_rows": int((1-primary_single.r).sum()),
    }
    (HERE / "prepared_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    counts["primary_untrimmed_single_men"] = len(primary_single)
    counts["primary_untrimmed_observed"] = int(primary_single.r.sum())
    counts["primary_untrimmed_missing"] = int((1-primary_single.r).sum())
    counts["primary_untrimmed_households"] = primary_single.household_id.nunique()
    counts["primary_author_trimmed_flag"] = int(primary_single.author_trimmed.sum())
    counts["primary_log_wage_summary"] = primary_single.y.describe().to_dict()
    counts["archive_sha256"] = hashlib.sha256(archive.read_bytes()).hexdigest()
    counts["dta_sha256"] = hashlib.sha256((HERE / "wagedata.dta").read_bytes()).hexdigest()
    (HERE / "sample_summary.json").write_text(json.dumps(counts, indent=2), encoding="utf-8")
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    prepare()
