# Public FES wage data: provenance and preparation

Downloaded 2026-09-18. The supplied PDF is a ten-page inventory of multiple
Heckman-style examples, rather than a paper defining a single dataset. We chose
its first-ranked empirical example: Arellano and Bonhomme (2017), *Quantile
Selection Models with an Application to Understanding Changes in Wage
Inequality*, Econometrica 85(1), 1--28, DOI
[10.3982/ECTA14030](https://doi.org/10.3982/ECTA14030).

## Primary sources

- [Journal article and replication materials](https://www.econometricsociety.org/publications/econometrica/2017/01/01/quantile-selection-models-application-understanding-changes).
- [Coauthor Stephane Bonhomme's research page](https://sites.google.com/site/stephanebonhommeresearch/),
  entry “Quantile Selection Models”, links directly to the downloaded archive.
- [Authors' public replication archive](https://drive.google.com/file/d/0B13ohL0_ULTDMVhBN0s1OXhldWc/view?resourcekey=0-dIhzC3g5wMpbtap-CnHhSw&usp=sharing).
  Download endpoint is recorded in `prepare_heckman.py`.
- [Authors' paper](https://drive.google.com/file/d/0B13ohL0_ULTDWXNXekR3Nm5FTzg/view?resourcekey=0--HMiFp34OKo4g8SQHf8akA&usp=sharing),
  especially section 5.1 and footnote 14. Local copy: `QRS_final_paper.pdf`.

The downloaded `Codes_for_replication.zip` contains an actual `wagedata.dta`
microdata file, not merely analysis instructions. No login or access application
was required. Source archive SHA256:
`fb05bf44da4aaa7e26351cc1180835129952377642d5ed980234c3444e25df59`.
Original `wagedata.dta` SHA256:
`30d18a2f9019de8a38103d0196d983fb1eb5a947f2b7b6ca79ac1e88dd624389`.
The archive is retained unchanged. An explicit redistribution license was not
identified; these are the authors' openly posted replication materials.

## Variables and substantive setting

The source has 187,616 individuals and 36 columns from the UK Family Expenditure
Survey, 1978--2000. The authors preselected people aged 23--59 who were not in
full-time education. Hourly wage is weekly pre-tax earnings divided by usual
weekly working hours. The outcome here is its natural logarithm. `work` records
employment; nonworkers do not have observed latent wage offers. Do **not** set
their wage to zero, or evaluate population coverage against zero/imputed values.

`ben_inc` is potential out-of-work welfare income, computed using the Institute
for Fiscal Studies tax and benefit simulation model. It is an excluded
participation predictor in the authors' analysis. We expose its logarithm as
`instrument`/`z_cont`. It is continuous; any discretization must be learned from
the training split alone. It is not a randomized instrument, and its exclusion
restriction is an assumption. The original paper discusses possible violations
because housing costs can affect benefits while correlating with wage potential.

Available covariates include age, end-of-schooling categories (`ed17`, `ed18`),
year, region, and counts of children in six age categories. Covariates and
instrument are observed for nonworkers as well. Predictors in
`prepared_metadata.json` have no missing values in the prepared primary cohort.
Counts of children are counts, despite being called “dummies” in parts of the
source paper. Household reference numbers are scoped to survey year, and the
prepared `household_id` is `year_hhref`; split by household to keep coresidents
together. `row_id` is the zero-based row number in the original dataset.

## Auditable preparation

Run `python experiments/data/heckman/prepare_heckman.py` from the repository root.
The script reads the original archive and exports CSV. Stata format 110 requires
`pyreadstat` for the first conversion; subsequent runs read `wagedata.csv` with
pandas. It writes:

- `prepared.csv`: the primary single-male cohort **without outcome-tail
  trimming**. Exclude self-employed people, missing schooling, nonpositive
  benefit income, and workers with invalid/nonpositive wages. Keep nonworkers
  with missing outcomes. There are **19,306** men, of whom **14,030** have observed
  wages and **5,276** are nonworkers; there are **18,156** household identifiers.
  The selected column aliases are `outcome`, `observed`, `instrument`, `row_id`,
  and `household_id`.
- `fes_clean.csv` and `fes_single_men.csv`: the authors' original cleaning,
  including their within-sex/year wage-tail removal (the first 9 and last 10
  ordered valid wages). It reproduces exactly their published final sample
  sizes: **77,630 men and 89,848 women**. Single men number **19,209**, with
  **13,933** observed wages. The primary `author_trimmed` flag identifies the
  **97** rows removed in this sensitivity cohort. Tie order is resolved by
  original row number, deterministically; original Stata sort tie order need
  not be identical, but equal wage thresholds have identical outcome values.
- `sample_summary.json`, `prepared_metadata.json`, `variable_labels.json`:
  machine-readable audit and feature metadata.

The original authors analyze gender/marital-status strata separately. Single
men supply a substantial sample with evidence of stronger selection in their
original application. This choice does not validate the wage exclusion
restriction. We pool survey years and therefore include year among predictors.

## What coverage can and cannot be measured

Natural nonworker wages are unobserved. In an analysis that uses employment as
the response indicator, interval lengths and respondent-only held-out coverage
are observable, but coverage for nonworkers or the whole eligible cohort is not.
A complete-observed benchmark can instead take the 14,030 workers, hide some
wages using a controlled outcome-dependent response mechanism, and evaluate on
the withheld real wages. That evaluates prediction for the employed complete-
observed cohort under the imposed masking law. It is a semisynthetic selection
experiment on real outcomes, not empirical confirmation of coverage for the
unemployed. If a randomized synthetic instrument is used in that benchmark, it
must be distinguished from the natural benefit-income instrument.

Source PDF renderings (`page1.png`--`page10.png`) only facilitate inspection of
the supplied inventory, whose embedded font encoding prevents normal text
extraction. `description.txt` is that failed direct extraction and is not a
usable source of text. No data were inferred from that extraction.
